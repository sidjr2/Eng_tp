import java.util.ArrayList;
import java.util.Scanner;

public class menu {
    public double subTotal;
    public static double valorTotal;
    private static double itemPreco;
    static boolean ordem = true;
    static Scanner input = new Scanner(System.in);
    static ArrayList<String> itemCompra = new ArrayList<>();
    public static void cardapio(){
        System.out.println("BEM-VINDO AO RESTAURANTE DCOMP \n" +
                "\t\t  CARDAPIO \n\n" +
                "1. SELF SERVICE  \n" +
                "2. PRATO FEITO \n" +
                "3. MARMITEX \n" +
                "4. BEBIDA \n" +
                "0. ENCERRAR VENDA");
    }
    public static void ItemValor(int foodItem) {

        if (foodItem == 1) {
            // TODO: 22/10/2022 precisa verificar se e fds ou dia de semana pra exibir o valor do self service corretamente
            System.out.println("SELF SERVICE");
            itemPreco = 20.00;
            int aux = quantidade();
            itemCompra.add("SELF SERVICE");
            itemCompra.add("Quantidade: "+ String.valueOf(aux));
        }
        if (foodItem == 2) {
            //fries = $1.50
            // TODO: 22/10/2022 precisa verificar se e fds ou dia de semana pra exibir o valor do PRATO FEITO corretamente
            System.out.println("PRATO FEITO");
            itemPreco = 16.00;
            int aux = quantidade();
            itemCompra.add("PRATO FEITO");
            itemCompra.add(String.valueOf(aux));
        }
        if (foodItem == 3) {
            int aux ;
            System.out.println("\n                 MARMITEX                 \n");
            System.out.println("\n1 - MARMITEX PEQUENA       (R$08.00)" +
                               "\n2 - MARMITEX MEDIA         (R$10.00)" +
                               "\n3 - MARMITEX GRANDE        (R$15.00)" +
                               "\n4 - MARMITEX 2 PESSOAS     (R$40.00)" +
                               "\n0 - NENHUMA BEBIDA\n");
            aux = input.nextInt();
            switch (aux){
                case 1:
                    itemPreco = 8.00;
                    int qtd = quantidade();
                    double subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: MARMITEX PEQUENA");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 2:
                    itemPreco = 10.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: MARMITEX MEDIA");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 3:
                    itemPreco = 15.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: MARMITEX GRANDE");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 4:
                    itemPreco = 40.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: MARMITEX 2 PESSOAS");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 0:
                    itemPreco = 0.00;
                    quantidade();
                    break;
            }
        }
        if(foodItem == 4){
            int aux ;
            System.out.println("\n                 BEBIBA                 \n");
            System.out.println("\n1 - REFRIGERANTE CACULINHA     (R$02.00)" +
                               "\n2 - REFRIGERANTE LATA          (R$05.00)" +
                               "\n3 - REFRIGERANTE 600ML         (R$06.00)" +
                               "\n4 - REFRIGERANTE 1 LITRO       (R$08.00)" +
                               "\n5 - REFRIGERANTE 2 LITRO       (R$12.00)" +
                               "\n0 - NENHUMA BEBIDA\n");
            aux = input.nextInt();
            switch (aux){
                case 1:
                    itemPreco = 2.00;
                    int qtd = quantidade();
                    double subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: REFRIGERANTE CACULINHA");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 2:
                    itemPreco = 5.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: REFRIGERANTE LATA");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 3:
                    itemPreco = 6.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: REFRIGERANTE 600ML");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 4:
                    itemPreco = 8.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: REFRIGERANTE 1 LITRO");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 5:
                    itemPreco = 12.00;
                    qtd = quantidade();
                    subTotal1 = subTotal(qtd, itemPreco);
                    itemCompra.add("ITEM: REFRIGERANTE 2 LITRO");
                    itemCompra.add("QUANTIDADE: " + qtd);
                    itemCompra.add("SUBTOTAL: " +String.valueOf(subTotal1));
                    itemCompra.add("-----------------------------------------------------");
                    break;
                case 0:
                    itemPreco = 0.00;
                    break;
            }

        }
    }
    public static int quantidade() {
        System.out.println("QUANTOS ITEM DESEJA:");
        int qtd = input.nextInt();
        return qtd;
    }
    public static double subTotal(double qtd, double itemPreco) {
        double subTotal = (qtd * itemPreco);
        System.out.println("SUBTOTAL: "+ subTotal);
        valorTotal += subTotal;
        return valorTotal;
    }
    public static void Venda(){
        ordem = false;
        System.out.println("\n---------------------------------\n" +
                           "\t\t RESTAURANTE DCOMP\n" +
                            "\t\t EXTRATO DA CONTA\n" +
                           "\n---------------------------------\n");
        for (String s:itemCompra) {
            System.out.println(s);
        }
        System.out.println("\t\tVALOR TOTAL : "+valorTotal);
        System.out.println("\n---------------------------------\n");
        System.out.println("\t\tBOA REFEIÇÃO !!!!");
    }
    public static void main(String[] args) {
        int menuOption;
        int foodItem;
        input = new Scanner(System.in);
        do{
            double runningTotal=0;
            cardapio();
            menuOption = input.nextInt();
            switch(menuOption){
                case 1:
                    foodItem = 1;
                    ItemValor(foodItem);
                    break;
                case 2:
                    foodItem = 2;
                    ItemValor(foodItem);
                    break;
                case 3:
                    foodItem = 3;
                    ItemValor(foodItem);
                    break;
                case 4:
                    foodItem = 4;
                    ItemValor(foodItem);
                    break;
                case 0:
                    Venda();
                    break;
                default:
                    System.out.println("ERROR!\n OPÇÃO INVALIDA!");
            }

        } while(ordem); {
        }
    }
}