package br.com.restaurantedcomptest.controlador;

public class Controlador {
}
