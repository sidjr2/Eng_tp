package br.com.restaurantedcomptest.fabrica;

public class Fabrica {
}
