package br.com.restaurantedcomptest.entidade;
// TODO: 21/10/2022  model
public class Entidade {
}
