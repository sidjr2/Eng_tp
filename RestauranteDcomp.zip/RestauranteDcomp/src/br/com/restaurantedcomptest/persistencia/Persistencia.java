package br.com.restaurantedcomptest.persistencia;

// TODO: 21/10/2022  seria como fosse o arquivo ou o bd
public class Persistencia {
}
