package br.com.restaurantedcomptest.visao;

public class Visao {
}
