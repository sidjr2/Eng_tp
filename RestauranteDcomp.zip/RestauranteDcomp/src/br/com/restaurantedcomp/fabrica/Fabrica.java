package br.com.restaurantedcomp.fabrica;

public class Fabrica {
}
