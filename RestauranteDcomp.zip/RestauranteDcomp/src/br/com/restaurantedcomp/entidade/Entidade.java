package br.com.restaurantedcomp.entidade;
// TODO: 21/10/2022  model
public class Entidade {
}
