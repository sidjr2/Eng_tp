package br.com.restaurantedcomp.controlador;

public class Controlador {
}
