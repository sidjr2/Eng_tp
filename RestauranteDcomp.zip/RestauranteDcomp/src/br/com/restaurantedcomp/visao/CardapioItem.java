package br.com.restaurantedcomp.visao;

import java.util.ArrayList;
import java.util.Scanner;

public class CardapioItem {
    public  String nome;
    public  String tamanho;
    public  float preco;
    public static int id = 0;
    public CardapioItem(){

    }

    public CardapioItem(int id, String nome, String tamanho, float preco) {
        this.id = id;
        this.nome = nome;
        this.tamanho = tamanho;
        this.preco = preco;
    }
    public void imprimeCardapio(){
        System.out.println("--------------------------");
        System.out.println("CODIGO DO ITEM: " + this.getId());
        System.out.println("NOME DO ITEM: " + this.getNome());
        System.out.println("TAMANHO DO ITEM: " + this.getTamanho());
        System.out.println("VALOR DO ITEM: R$ " + this.getPreco());
        System.out.println("--------------------------");
    }

   /* public static CardapioItem insereItem(ArrayList<CardapioItem> cardapioItem){
        Scanner scann = new Scanner(System.in);
        int aux = id+1;
        System.out.println("\nDIGITE O NOME DO PRODUTO: ");
        cardapioItem. = scann.nextLine();
        scann.nextLine();
        System.out.println("\nTAMANHO DO ITEM " + cardapioItem.nome + ":");
        cardapioItem.tamanho = scann.next();
        scann.nextLine();
        System.out.println("\nDIGITE O VALOR DO ITEM " + cardapioItem.nome + ":");
        cardapioItem.preco = scann.nextFloat();
        new CardapioItem(aux, cardapioItem.nome, cardapioItem.tamanho, cardapioItem.preco);
        return null;
    }*/
    public int getId() {
        return id;
    }

    public float getPreco() {
        return preco;
    }

    public String getNome() {
        return nome;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    @Override
    public String toString() {
        return "CardapioItem{" +
                "id='" + id + '\'' +
                "nome='" + nome + '\'' +
                ", tamanho='" + tamanho + '\'' +
                ", preco=" + preco +
                '}';
    }
}
