package br.com.restaurantedcomp.visao;

import java.util.List;
import java.util.ArrayList;

public class Cardapio extends CardapioItem{


}
