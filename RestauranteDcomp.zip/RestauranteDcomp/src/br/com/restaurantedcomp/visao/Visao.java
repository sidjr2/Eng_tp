package br.com.restaurantedcomp.visao;

import br.com.restaurantedcomp.visao.test.CardapioItemtest;
import br.com.restaurantedcomp.visao.test.Vendatest;

import java.util.Scanner;

public class Visao {
    public static void menu(){
        Scanner scann = new Scanner(System.in);
        int op = 0;
        do{
            System.out.println("\n\t Restaurante Dcomp\n" +
                    "                   =========================\n" +
                    "                  |     1 - Comprar         |\n" +
                    "                  |     2 - Cardapio        |\n" +
                    "                  |     0 - Sair            |\n" +
                    "                   =========================\n");
            System.out.println("--> ");
            op = scann.nextInt();
            switch (op){
                case 1 :
                    Vendatest.main();
                    break;
                case 2:
                    CardapioItemtest.main();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("OPCAO INVALIDA!");
                    break;
            }
        }while (op !=0);
    }
}
