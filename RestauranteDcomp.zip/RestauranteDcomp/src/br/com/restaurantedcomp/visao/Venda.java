package br.com.restaurantedcomp.visao;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Venda {
    public Date data; //dia e hora
    public int id;
    public String nome;
    public float total;
    public int qtd_venda;

    public String getNome() {
        return nome;
    }

    public static void Date(){
        Date datah = new Date();
        String data = new SimpleDateFormat("dd/MM/yyyy").format(datah);
        String hora = new SimpleDateFormat("HH:mm:ss").format(datah);
        System.out.println("\nDATA: " + data + "\nHORA: " + hora);
    }

    public static float CalculaTotal(int id, int qtd_venda){
        float total = 0;
        CardapioItem cardapioItem;
        if(id == 0) {
            cardapioItem = new CardapioItem(0, "Salgado", "grande", 7.00F);
            //total = (qtd_venda*preco);
        }else{
            cardapioItem = new CardapioItem(1, "Refrigerante", "600ml", 5.00F);
            //total = (qtd_venda*preco);
        }
        System.out.println("Nome: " + cardapioItem.nome);
        total = (qtd_venda * cardapioItem.preco);

        System.out.println("Valor total do item: " + total);
        return total;
    }

    public Date getData() {
        return data;
    }

    public float getTotal() {
        return total;
    }

    public int getId() {
        return id;
    }

    public int getQtd_venda() {
        return qtd_venda;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setQtd_venda(int qtd_venda) {
        this.qtd_venda = qtd_venda;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Venda{" +
                "data=" + data +
                ", id=" + id +
                ", nome='" + nome + '\'' +
                ", total=" + total +
                ", qtd_venda=" + qtd_venda +
                '}';
    }
}
