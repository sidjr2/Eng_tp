package br.com.restaurantedcomp.visao.test;

import br.com.restaurantedcomp.visao.Visao;

public class Visaotest extends Visao{
    public static void main(String[] args) {
        Visao.menu();
    }
}
