package br.com.restaurantedcomp.visao.test;

import br.com.restaurantedcomp.visao.CardapioItem;

import java.util.ArrayList;

public class CardapioItemtest {
    public static void main() {
        System.out.println("CADASTRO DE ITEM NO RESTAURANTE DCOMP");
        ArrayList<CardapioItem> cardapioItem = new ArrayList<>();

       // cardapioItem.add(CardapioItem.insereItem(cardapioItem));

       System.out.println(cardapioItem);
    }
}
