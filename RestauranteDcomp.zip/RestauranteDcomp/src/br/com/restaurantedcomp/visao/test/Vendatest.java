package br.com.restaurantedcomp.visao.test;


import java.util.Date;
import java.util.Scanner;

import static br.com.restaurantedcomp.visao.Venda.CalculaTotal;


public class Vendatest {
    private static float total;

    public static void main() {
        int op = 1;
        System.out.println("CAIXA RESTAURANTE DCOMP");
        Date date = new Date();
        System.out.println(date);
        Scanner scan = new Scanner(System.in);
        while (op != 0) {
            System.out.println("DIGITE O ID DO PRODUTO: ");
            int id = scan.nextInt();
            System.out.println("DIGITE A QUANTIDADE DE PRODUTO ADQUERIDOS: ");
            int qtd = scan.nextInt();
            total = (total + CalculaTotal(id, qtd));
            System.out.println("\nDESEJA ADD OUTRO PRODUTO?\n0 - NAO\t1- SIM");
            op = scan.nextInt();
        }
        System.out.println("Valor total da compra: " + total);
        //venda.nome = "Refrigerante"; tem que ser regatta usando o id
        //venda.total = CalculaTotal(venda.qtd_venda, venda.id);

    }



}
